 <div class="topbar dark topbar-padding">
    <div class="container">
      <div class="topbar-left-items">
        <ul class="toplist toppadding pull-left paddtop1">
          <li style="color:white;" class="rightl">Mobile No</li>
          <li style="color:white;">+91 909 644 6999</li>
        </ul>
      </div>
      <!--end left-->
      
      <div class="topbar-right-items pull-right">
        <ul class="toplist toppadding">
          <li><a target="_blank" href="https://www.facebook.com/wealthcreationfinancialservice/"><i class="fa fa-facebook"></i></a></li>
          <li><a href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
          <li><a href="javascript:void(0);"><i class="fa fa-linkedin"></i></a></li>
           <li><a href="https://t.me/joinchat/AAAAAEvqEMYGPMdMIYL9EA"><i class="fa fa-telegram"></i></a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="clearfix"></div>
  
  <div id="header">
    <div class="container-fluid nopadding">
      <div class="navbar red-4 navbar-default yamm">
        <div class="navbar-header" style="background-color:white !important;">
          <button type="button" data-toggle="collapse" data-target="#navbar-collapse-grid" class="navbar-toggle two three"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
          <div class="logo-box" style="background-color: white !important;"><a href="index.php" class="navbar-brand less-top-padding"><img style="margin-top: -16px;" src="images/logo.jpg" alt=""/></a></div>
        </div>
        <div id="navbar-collapse-grid" class="navbar-collapse collapse pull-right">
          <ul class="nav red-4 navbar-nav">
            <li><a href="index.php" class="dropdown-toggle <?php if($pagename=='home'){ echo "active"; }?>">Home</a></li>
            <li><a href="about.php" class="dropdown-toggle <?php if($pagename=='about'){ echo "active"; }?>">About</a></li>
            <li><a href="news.php" class="dropdown-toggle <?php if($pagename=='news'){ echo "active"; }?>">Wealth News</a></li>
            <li><a href="knowledge.php" class="dropdown-toggle <?php if($pagename=='know'){ echo "active"; }?>">Knowledge Cafe</a></li>
            <li><a href="services.php" class="dropdown-toggle <?php if($pagename=='service'){ echo "active"; }?>">Services</a></li>
            <li><a href="download.php" class="dropdown-toggle <?php if($pagename=='download'){ echo "active"; }?>">Downloads</a></li>
           <li><a href="contact.php" class="dropdown-toggle <?php if($pagename=='contact'){ echo "active"; }?>">Contact</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>